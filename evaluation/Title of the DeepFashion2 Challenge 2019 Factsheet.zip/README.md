# DeepFashion2_factsheet_2019
Latex template the factsheet for DeepFashion2 Challenge 2019
